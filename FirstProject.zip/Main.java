import java.util.*;

public class Main {

  public static void main(String[] args) {

    Scanner user_input = new Scanner(System.in);

    System.out.println("Hello!\n\n");

    System.out.println("First Name:");
    String One = user_input.nextLine();
    System.out.println("\n\n");

    System.out.println("Last Name:");
    String Three = user_input.nextLine();
    System.out.println("\n\n");

    System.out.println("Middle Initial:");

    String Six = user_input.nextLine();
    System.out.println("\n\n");

    System.out.println("Hometown:");

    String Two = user_input.nextLine();
    System.out.println("\n\n");

    System.out.println("Age:");

    String Four = user_input.nextLine();
    System.out.println("\n\n");

    System.out.println("Date:");

    String Five = user_input.nextLine();
    System.out.println("\n\n");

    System.out.println(One + " " + Six + " " + Three);
    System.out.println(Two);
    System.out.println(Four);
    System.out.println(Five);
  }
}
